---
name: use-medical-blocks
description: 本项目医学统计 Block 开发规范。当编写、修改、拆分任意 Block（data_clean/imputation/baseline/cox/logistic/km/subgroup 等）时必须遵守。包含 ctx 契约、I/O 封装、发表编号、pause 机制、命名规范。完整规范见 BLOCKS_USAGE_GUIDE.md。
---

# Medical Blocks 开发规范速查

> 完整规范：`BLOCKS_USAGE_GUIDE.md`  
> 拆分规范：`.cursor/skills/split-medical-block/SKILL.md`  
> 新建 config：`.cursor/skills/create-pipeline-config/SKILL.md`

## 绝对红线（违反直接拒绝）

1. **不硬编码**：路径、列名、阈值、序号均从 `config` 读，用 `%||%` 兜底
2. **不在块内选数据源**：不加 `config$xxx$data_source`，数据源由 pipeline 顺序决定
3. **不跨块调用**：块间只通过 `ctx` 传值，禁止 `source` 其他块的函数
4. **不用 `set.seed()`**：随机数种子只在 `config$imputation$seed` 等全局 config 设
5. **不手写发表序号**：禁止 `"Table S2."` / `"Figure 3."` 硬编码，必须用 `pub_*` API

## Block 标准结构

```r
###############################################################################
#  block_xxx.R — 功能描述
#  register_block: "xxx"
#  读: ctx$data$imputed %||% ctx$data$cleaned
#  写: ctx$results$xxx_result
#  产出:
#    - [supp_table] Table Sn.* 描述   → pub_paths + export_sci_table
#    - [main_figure] Figure n.* 描述  → pub_figure_file + save_figure
###############################################################################

block_xxx <- function(ctx, ...) {
  cfg    <- ctx$config
  bl_cfg <- cfg$xxx %||% list()

  # 1. 数据入口（不在此选数据源）
  data <- ctx$data$imputed %||% ctx$data$cleaned
  if (is.null(data) || !is.data.frame(data))
    stop("xxx: 需先运行 data_clean / imputation", call. = FALSE)

  # 2. 核心统计逻辑

  # 3. 产出（发表表用 pub_paths，图用 pub_figure_file）

  # 4. 返回 ctx
  ctx
}

register_block("xxx", block_xxx, "功能中文描述")
```

## 数据槽位（只读，不配置选源）

| 场景 | 读取槽位 |
|------|---------|
| 插补后分析（baseline/UV/VIF/Logistic GLM/Cox） | `ctx$data$imputed %||% ctx$data$cleaned` |
| NHANES 加权分析 | `ctx$results$nhanes_design`（须先跑 `obj` block） |
| ML 训练/ROC/SHAP | `ctx$data$train` / `ctx$data$validation` |

## I/O 封装规则

```r
# ✅ 保存图形（Times New Roman 已内置）
save_figure(ctx, fig_fn, function() { ... })

# ✅ 导出发表三线表（同时产出 .xlsx + .tex）
export_sci_table(df, filepath, title = paths$title)

# ❌ 禁止直接写文件
ggsave("Figure 3. KM.pdf", ...)
write.csv(df, "Table S2. VIF.csv")
```

## 发表自动编号 API

| 函数 | 用途 | 返回 |
|------|------|------|
| `pub_paths(ctx, dir, kind, caption, ext)` | 发表表 | `list(title, filepath)` |
| `pub_pair(ctx, dir, kind, title_caption, file_caption, ext)` | 表标题与文件名描述不同 | `list(title, filepath)` |
| `pub_figure_file(ctx, kind, caption, ext)` | 发表图 | 文件名 basename |
| `pub_title(ctx, kind, caption)` | 仅需标题字符串 | 字符串 |

`kind` 四选一：`"main_table"` / `"main_figure"` / `"supp_table"` / `"supp_figure"`  
`caption` **只写描述，不含序号**（系统自动补 `Table S2. `）

```r
# 补充表（最常见）
paths <- pub_paths(ctx, ctx$output_dir_tables, "supp_table",
                   "Multicollinearity Analysis (VIF)", "xlsx")
export_sci_table(tbl, paths$filepath, title = paths$title)

# 主图
fn <- pub_figure_file(ctx, "main_figure", "Kaplan-Meier survival curves")
ctx <- save_figure(ctx, fn, function() { plot_km(...) })
```

## 不参与自动编号（保持固定描述性文件名）

- `VIF_check_screen.csv`、`data_quality_report.csv`（诊断辅助）
- `Table_ROC_summary.xlsx`、`Table Boxplot GroupComparisons.xlsx`（下划线/非 `Table n.` 格式）
- `Figure S2A.LassoGenes.pdf`（字母后缀子图）
- `Model2Factors.txt`、`D01_AfterMI_Data.RData`（中间数据）

## Pause 机制

```r
# 配置
bl_cfg$pause_enable    <- TRUE   # 总开关（批量运行时设 FALSE）
bl_cfg$pause_on_xxx    <- TRUE   # 具体触发条件

# 触发时
ctx$results$pause_point <- list(
  block = "xxx", reason = "中英双语原因", data = ...
)
stop("xxx [PAUSE]: 原因（调整参数后用 --from xxx 续跑）")
```

批量运行时所有 `pause_enable = FALSE`，不交互。

## 新增/修改 Block 前必做：产出物确认表

编写任何产生表/图的 Block 前，先向用户列清单：

```
| # | 产出说明 | 类型 | 发表序号？ | kind | 确认 |
|---|----------|------|-----------|------|------|
| 1 |          |      | 是/否     |      | ☐    |
```

判定口诀：
- 稿件里会写 `Table 1` / `Figure 2` / `Table S1` / `Figure S1` → **是**，用 `pub_*`
- 仅内部诊断 / 子图 / 固定名 → **否**，描述性文件名

## 文件命名规范

```
Blocks/
├── 04_baseline/
│   ├── 01block_baseline_binary.R
│   └── 02block_baseline_multiclass.R
├── 10_cox/
│   └── 03block_cox_quartile.R
```

- 目录前缀 `NN`（两位）= pipeline 顺序，**新建目录前必须问用户**
- 子块文件名 `01`/`02` = 模块内部顺序，与目录 `NN` 无关
- 私有函数加文件级前缀（如 `.bb01_`）避免 source 后名称冲突

## 注册到 pipeline

在 `R/pipeline_runner.R` 的 `pipeline_block_sources()` 里添加：

```r
block_xxx = b("NN_module/01block_xxx.R"),
```

## 完整规范参考

详细内容（数据槽位约定、export_sci_table 参数、pub_* 完整 API、Table 1 渲染 spec、ML block 系列）见 `BLOCKS_USAGE_GUIDE.md`。
